package com.cts;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.cts")
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
		Employee emp = (Employee) context.getBean("employee");
		System.out.println(emp);
		System.out.println(emp.getAddress());

	}

	@Bean("employee")
	public Employee getEmployee() {
		Employee emp = new Employee();
		emp.setAddress(getAddress());
		return emp;

	}

	@Bean
	public Address getAddress() {
		return new Address();
	}

}
